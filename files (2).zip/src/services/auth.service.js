const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/user.model');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
require('dotenv').config();

exports.register = async ({ email, password }) => {
  const password_hash = await bcrypt.hash(password, 10);
  const user = await User.create({ email, password_hash });
  return user;
};

exports.login = async ({ email, password }) => {
  const user = await User.findOne({ where: { email } });
  if (!user) throw { status: 400, message: 'Invalid credentials' };

  const match = await bcrypt.compare(password, user.password_hash);
  if (!match) throw { status: 400, message: 'Invalid credentials' };

  const token = jwt.sign(
    { id: user.id, email: user.email },
    process.env.JWT_SECRET,
    { expiresIn: '1h' }
  );
  return { token };
};

exports.forgotPassword = async ({ email }) => {
  const user = await User.findOne({ where: { email } });
  if (!user) return; // Don't reveal user existence

  const reset_token = crypto.randomBytes(32).toString('hex');
  const reset_token_expiry = new Date(Date.now() + 3600000); // 1h

  await user.update({ reset_token, reset_token_expiry });

  // Send email
  const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT || 587,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${reset_token}`;
  await transporter.sendMail({
    to: user.email,
    subject: 'Password Reset',
    text: `Reset your password here: ${resetUrl}`,
  });
};

exports.resetPassword = async ({ token, password }) => {
  const user = await User.findOne({
    where: {
      reset_token: token,
      reset_token_expiry: { [require('sequelize').Op.gt]: new Date() }
    }
  });
  if (!user) throw { status: 400, message: 'Invalid or expired token' };

  const password_hash = await bcrypt.hash(password, 10);
  await user.update({ password_hash, reset_token: null, reset_token_expiry: null });
};

exports.logout = async () => {
  // With JWT, logout is handled on client-side by deleting token.
  // Optionally, implement a blacklist.
  return;
};