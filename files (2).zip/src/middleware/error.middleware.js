module.exports = (err, req, res, next) => {
  // Validation error
  if (err.errors) {
    return res.status(400).json({ errors: err.errors.map(e => e.msg) });
  }
  res.status(err.status || 500).json({ message: err.message || 'Server error' });
};