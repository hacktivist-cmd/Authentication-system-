const { validationResult } = require('express-validator');
const authService = require('../services/auth.service');

exports.register = async (req, res, next) => {
  try {
    const errors = validationResult(req); if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const user = await authService.register(req.body);
    res.status(201).json({ message: 'User registered', email: user.email });
  } catch (err) { next(err); }
};

exports.login = async (req, res, next) => {
  try {
    const errors = validationResult(req); if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    const data = await authService.login(req.body);
    res.json(data);
  } catch (err) { next(err); }
};

exports.forgotPassword = async (req, res, next) => {
  try {
    const errors = validationResult(req); if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    await authService.forgotPassword(req.body);
    res.json({ message: 'If that email exists, a reset link was sent.' });
  } catch (err) { next(err); }
};

exports.resetPassword = async (req, res, next) => {
  try {
    const errors = validationResult(req); if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });
    await authService.resetPassword(req.body);
    res.json({ message: 'Password reset successful' });
  } catch (err) { next(err); }
};

exports.logout = async (req, res, next) => {
  try {
    await authService.logout();
    res.json({ message: 'Logged out' });
  } catch (err) { next(err); }
};