const { body } = require('express-validator');

exports.registerValidation = [
  body('email').isEmail().withMessage('Valid email required'),
  body('password').isLength({ min: 6 }).withMessage('Password min 6 chars'),
];

exports.loginValidation = [
  body('email').isEmail(),
  body('password').exists(),
];

exports.forgotPasswordValidation = [
  body('email').isEmail(),
];

exports.resetPasswordValidation = [
  body('token').exists(),
  body('password').isLength({ min: 6 }),
];