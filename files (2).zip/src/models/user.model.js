const { DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const User = sequelize.define('User', {
  email: {
    type: DataTypes.STRING,
    unique: true,
    allowNull: false,
    validate: { isEmail: true }
  },
  password_hash: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  reset_token: DataTypes.STRING,
  reset_token_expiry: DataTypes.DATE,
}, {
  timestamps: true,
});

module.exports = User;